        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">

				<ul class="metismenu" id="menu">
                    <li><a href="." aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                    </li>
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-briefcase"></i>
							<span class="nav-text">My Money</span>
						</a>
						<ul aria-expanded="false">
							<li><a href="#1">Request</a></li>
							<li><a href="#2">Send</a></li>
							<li><a href="#3">Withdraw</a></li>
						</ul>
                    </li>
                    
					<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-internet"></i>
							<span class="nav-text">Utilities</span>
						</a>
						<ul aria-expanded="false">
                            <li><a href="#4">Airtime/Data</a></li>
                            <li><a href="#5">Settlements</a></li>
                        </ul>
					</li>
                   
                    <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-smartphone-5"></i>
							<span class="nav-text">Packages</span>
						</a>
						<ul aria-expanded="false">
                            <li><a href="#6">Alajoo</a></li>
                        </ul>
                    </li>
					<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-settings-1"></i>
							<span class="nav-text">Settings</span>
						</a>
						<ul aria-expanded="false">
                            <li><a href="security.php">Security</a></li>
                            <li><a href="#8">Transaction</a></li>
                            <li><a href="profile.php#profile-settings">Account</a></li>
                        </ul>
					</li>
					<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
							<i class="flaticon-381-file-1"></i>
							<span class="nav-text">Transactions</span>
						</a>
						<ul aria-expanded="false">
                            <li><a href="#10">Fund</a></li>
                            <li><a href="#11">Request</a></li>
                            <li><a href="#12">Withdraw</a></li>
                            <li><a href="#13">Airtime/Data</a></li>
                            <li><a href="#14">Settlements</a></li>
                        </ul>
					</li>
                </ul>
				
				<!-- <div class="copyright">
					<p><strong>Thrive Pay</strong> © Thrive FINTECH </p>
					<p>Made with <span class="heart"></span> by OpensDigital</p>
				</div> -->
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->