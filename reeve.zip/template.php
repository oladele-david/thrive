<?php
    require_once('utilities/appServer.php');
    if(session_status() != PHP_SESSION_ACTIVE)
    session_start();

    $userInSession = $_SESSION['userInSession'];
    $lastName = $_SESSION['lastName'];
    $firstName = $_SESSION['firstName'];
    $emailId = $_SESSION['emailId'];
    $phoneNo = $_SESSION['phoneNo'];

    if(empty($_SESSION['userInSession']))
    {
        header("Location: signin.php");
        
        die("Redirecting to signin.php");
    }
    $pageTitle = "Template";

    require_once('objects/accountRESTful.php');

?>

<?php include('header.php') ?>
<?php include('sidebar.php') ?>

<?php include('alerts.php') ?>

<?php include('footer.php') ?>
