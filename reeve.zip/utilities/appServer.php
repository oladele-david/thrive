<?php
	$serverURL = "http://108.166.219.78:6614/v1/";
?>

<?php
    $curl = curl_init();
    
    curl_setopt_array($curl, array(
        CURLOPT_URL =>  "http://108.166.219.78:6614/authenticate",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS =>"{\n\t\"username\":\"reeve-96\",\n\t\"password\":\"password\"\n}",
        CURLOPT_HTTPHEADER => array(
            "Authorization: ",
            "Content-Type: application/json"
        ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl); curl_close($curl);
    
    if($err) {
		//echo "cURL Error #:" . $err;
		$serviceOff = "The application server for the web services temporarily unavailable. Please bear with us as we seek to resolve as soon as possible. If this error persists for more than 15 minutes, please contact us through the LIVE chat below or reach us through any of our underlined contacts. Thank you.";
	} else {
		$gen_token = json_decode($response, true);
		$token = $gen_token['token'];
	}
?>
