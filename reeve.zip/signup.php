<?php
    require_once('utilities/appServer.php');
    
    if(session_status() != PHP_SESSION_ACTIVE)
    session_start();

    $randomID = mt_rand(10000000000, 99999999999);

    $lastName = ucfirst($_POST['lastName']);
    $firstName = ucfirst($_POST['firstName']);
    $phoneNo = $_POST['phoneNo'];
    $emailId = strtolower($_POST['emailId']);
    $password = $_POST['password'];

    // A sample PHP Script to POST data using cURL
    // Data in JSON format
    
    if(isset($_POST['create'])) {
        $data = array(
            'id' => $randomID,
            'accountNumber' => $phoneNo,
            'lastName' => $lastName,
            'firstName' => $firstName,
            'phoneNo' => $phoneNo,
            'emailId' => $emailId,
            'password' => $password
        );
        
        $payload = json_encode($data);
        
        // Prepare new cURL resource
        $api = curl_init($serverURL . "accounts/create");

        curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($api, CURLINFO_HEADER_OUT, true);
        curl_setopt($api, CURLOPT_POST, true);
        curl_setopt($api, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($api, CURLOPT_CUSTOMREQUEST, "POST");
        

        $_SESSION['userInSession'] = $randomID;
        $_SESSION['lastName'] = $lastName;
        $_SESSION['firstName'] = $firstName;
        $_SESSION['emailId'] = $emailId;
        $_SESSION['phoneNo'] = $phoneNo;

        //$_SESSION['password'] = $password;
        
       // Set HTTP Header for POST request 
       curl_setopt($api, CURLOPT_HTTPHEADER, array(
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json')
        );

        $response = curl_exec($api);
        $err = curl_error($api); curl_close($api);
        if ($err) {
            ob_clean();
            echo "fail";
            exit;
        } else {
            ob_clean();
            echo "success";
            exit;
        }
       
        exit;
    }

    if (isset($_POST['emailCheck'])) {
        $curl_check_mail = curl_init();

        curl_setopt_array($curl_check_mail, array(
        CURLOPT_URL => $serverURL.'accounts/emailId/'. $emailId,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer ' . $token
        ),
        ));

        $response_check_mail = curl_exec($curl_check_mail);

        curl_close($curl_check_mail);
        $data_check_mail = json_decode($response_check_mail, true);

        if  ($data_check_mail['id'] != null) {
            ob_clean();
            echo "exist";
            exit;
        } else {
            ob_clean();
            echo "notExist";
            exit;
        }
        exit;
    }

    if (isset($_POST['phoneCheck'])) {
        $curl_check_phone = curl_init();

        curl_setopt_array($curl_check_phone, array(
        CURLOPT_URL => $serverURL.'accounts/phoneNo/'. $phoneNo,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer ' . $token
        ),
        ));

        $response_check_phone = curl_exec($curl_check_phone);
        $err_check_phone = curl_error($curl_check_phone);


        curl_close($curl_check_phone);

        $data_check_phone = json_decode($response_check_phone, true);
        
            if  ($data_check_phone['id'] != null) {
                ob_clean();
                echo "exist";
                exit;
            } else {
                ob_clean();
                echo "notExist";
                exit;
            }
        
       
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en" class="h-100">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ReevePay | Sign up</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
	<link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                
                <div class="container-fluid">
                    <br>
                    <?php include('alerts.php') ?>
                </div>

                <div class="col-md-6">
					<div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="."><img src="images/logo-full.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Create your account</h4>
                                    <form method="POST" onsubmit="return createAccount()">
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Last Name</strong></label>
                                            <input type="text" class="form-control" id="lastName" name="textUsername" placeholder="Last Name" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>First Name</strong></label>
                                            <input type="text" class="form-control" id="firstName" name="textUsername" placeholder="First Name" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Phone Number</strong></label>
                                            <input type="text" class="form-control" id="phoneNo" name="textPhoneNo" placeholder="Phone Number" maxlength="11" onchange="return checkPhoneNo();" required>
                                            <div id="val-phone-error" class="invalid-feedback animated fadeInUp" style="display: none;">Phone No Exists Already, Try Another</div>
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Email</strong></label>
                                            <input type="email" id="emailId" name="textEmailId" class="form-control" placeholder="hello@example.com" onchange="return checkEmail();" required>
                                            <div id="val-email-error" class="invalid-feedback animated fadeInUp" style="display: none;">Email Exists Already, Try Another</div>
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Password</strong></label>
                                            <input type="password" id="password" name="textPassword" class="form-control" required>
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Confirm Password</strong></label>
                                            <input type="password" id="confirmPassword" name="textConfirmPassword" class="form-control" required>
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" id="buttonSignup" class="btn bg-white text-primary btn-block">Sign me up</button>
                                            <button type="submit" id="loading_spinner" class="btn bg-white text-primary btn-block" style="display: none;"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> Creating Account</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p class="text-white">Already have an account? <a class="text-white" href="signin.php">Sign in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/deznav-init.js"></script>
<script src="vendor/sweetalert2/dist/sweetalert2.min.js"></script>

<!-- signup script -->
<script>
    function checkEmail(){
        let emailId = $('#emailId').val();
                
        $.ajax
        ({
            type:'post',
            url:'signup.php',
            data:{
                emailCheck:"emailCheck",
                emailId:emailId
            },
            success:function(response) {
                if(response =="exist"){
                    $("#val-email-error").css({"display":"block"});
                    $("#buttonSignup").prop("disabled",true);
                    // console.log('This is==> '+ response);  
                    $('#emailId').val("");              
                }
                else {
                    $("#val-email-error").css({"display":"none"});
                    $("#buttonSignup").prop("disabled",false);
                    // console.log('This is==> '+ response);
                }
            }
        });
    }

    function checkPhoneNo(){
        let phoneNo = $('#phoneNo').val();
                
        $.ajax
        ({
            type:'post',
            url:'signup.php',
            data:{
                phoneCheck:"phoneCheck",
                phoneNo:phoneNo
            },
            success:function(response) {
                if(response =="exist"){
                    $("#val-phone-error").css({"display":"block"});
                    $("#buttonSignup").prop("disabled",true);
                    $("#phoneNo").val('');
                    // console.log('This is==> '+ JSON.stringify(response, null, "  "));
                }
                else {
                    $("#val-phone-error").css({"display":"none"});
                    $("#buttonSignup").prop("disabled",false);
                    // console.log('This is==> '+ JSON.stringify(response, null, "  "));
                
                }
            }
        });

    }

    // Sign Up script
    function createAccount(){
                
        //let accountNumber = $('#accountNumber').val();
        let lastName = $('#lastName').val();
        let firstName = $('#firstName').val();
        let phoneNo = $('#phoneNo').val();
        let emailId = $('#emailId').val();
        let password = $('#password').val();
        let confirmPassword = $('#confirmPassword').val();
       
        if (password == confirmPassword) {

            if(emailId!="" && phoneNo!="" && password!="") {
                
                $("#buttonSignup").css({"display":"none"});
                $("#loading_spinner").css({"display":"block"});
                $.ajax
                ({
                    type:'post',
                    url:'signup.php',
                    data:{
                        create:"create",
                        lastName:lastName,
                        firstName:firstName,
                        phoneNo:phoneNo,
                        emailId:emailId,
                        password:password
                    },
                    success:function(response) {
                        if(response =="success"){
                        $("#loading_spinner").css({"display":"none"});

                        swal({
                            
                            title: 'Account Created Successfully!',
                            text: "Hello "  + lastName + " " + firstName + ", welcome to Reeve",
                            confirmButtonText: 'Continue',
                            type: 'success',
                        }).then(function (result) {
                            if (true) {
                            window.location = "index.php";
                            }
                        })
                        // window.location.href="";
                        }
                        else {
                            $("#loading_spinner").css({"display":"none"});
                            $("#buttonSignup").css({"display":"block"});

                            swal({
                                type: 'error',
                                title: 'Declined!',
                                text: 'Account could not be created, seems email is taken ',
                                confirmButtonText: 'Try Again'
                            });
                            // alert("Wrong Details" + response);
                            //console.log(response + " - " + clientAccessID + " - " + phoneNo + " - " + wardId + " - " + password);
                        }
                    }
                });
                //console.log("Values entered are == " + lastName + " -- " + firstName + " -- " + emailId + " -- " + password + " -- " + confirmPassword + " -- " + phoneNo + " -- " );
                return false;

            }
            else
            {
                swal({
                type: 'error',
                title: 'Halt!',
                text: 'Please Fill All The Details'
                })
                //alert("Please Fill All The Details");
            }

            return false;

            //console.log("Values entered are == " + customerName + " -- " + emailID + " -- " + password + " -- " + confirmPassword + " -- " + phoneNo + " -- " + stateOfResidenceId + " -- " +  bankId + " -- " +  bankId + " -- " +  bankAccountName + " -- " +  bankAccountNo);
            //swal("Good job!", "You clicked the button! Welcome " + customerName + " -- " + emailID, "success");

        } else {
            //swal("Hey, Good job !!", "You clicked the button !!", "success")
            swal({
                type: "error",
                title: "Oh No!!",
                text: "Your passwords didn't match " + lastName + " " + firstName ,
                confirmButtonText: "Try Again"
            });
            //console.log("wrong password -- Values entered are == " + lastName + " -- " + firstName + " -- " + emailId + " -- " + password + " -- " + confirmPassword + " -- " + phoneNo + " -- " );
        return false;
        }
        //console.log("Values entered are == " + lastName + " -- " + firstName + " -- " + emailId + " -- " + password + " -- " + confirmPassword + " -- " + phoneNo + " -- " );
        return false;
    }
</script>

</body>

</html>