<?php
        $phoneNo = "08123456789";
        $password = "1234567";

    require_once('utilities/appServer.php');
        
    // $curl = curl_init();

    //     curl_setopt_array($curl, array(
    //     CURLOPT_URL => $serverURL.'accounts/accessID/'.$phoneNo.'/'.$password,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => '',
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => 'GET',
    //     CURLOPT_HTTPHEADER => array(
    //         'Authorization: Bearer ' . $token
    //     ),
    //     ));

    //     $response = curl_exec($curl);

    //     curl_close($curl);
    //     echo $response . "<br><br>". $token ."<br><br>";
        $curl_account_access = curl_init();

            curl_setopt_array($curl_account_access, array(
            CURLOPT_URL => 'http://108.166.219.78:6614/v1/accounts/accessID/'.$phoneNo.'/'.$password,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $token
            ),
            ));

            $response_account_access = curl_exec($curl_account_access);

            curl_close($curl_account_access);
            echo $response_account_access . "<br><br>". $token ."<br><br>";