<?php
// $serverURL = ""; // Set your server URL here

function fetchData($endpoint, $token, $method = 'GET', $data = []) 
{
    $url = $endpoint;
    $payload = json_encode($data);

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Basic " . $token,
            'Content-Type: application/json'
        ),
    ));

    $response = curl_exec($curl);
    $error = curl_error($curl);

    curl_close($curl);

    if ($error) {
        // this is not neccessary tho 
        // throw new \Exception("API request failed: " . $error);
        return "error message";
    }

    return json_decode($response, true);
}
