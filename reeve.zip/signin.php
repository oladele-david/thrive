<?php
    require_once('utilities/appServer.php');

    if(session_status() != PHP_SESSION_ACTIVE)
        session_start();

        $phoneNo = $_POST['phoneNo'];
        $password = $_POST['password'];

    
        $curl_account_access = curl_init();

            curl_setopt_array($curl_account_access, array(
            CURLOPT_URL => $serverURL.'accounts/accessID/'.$phoneNo.'/'.$password,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'GET',
            CURLOPT_HTTPHEADER => array(
                'Authorization: Bearer ' . $token
            ),
            ));

            $response_account_access = curl_exec($curl_account_access);
            $err_account_access = curl_error($curl_account_access);


            curl_close($curl_account_access);
            $data_account_access = json_decode($response_account_access, true);
            //echo $response_account_access . "<br><br>". $token ."<br><br>";
        // login starts here 

        if(isset($_POST['login'])) {
        
            if ($err_account_access) {
                ob_clean();
                echo "fail";
                exit;
            } else {
                
                if($data_account_access['emailId'] != NULL) {

                    $_SESSION['userInSession'] = $data_account_access['id'];
                    $_SESSION['lastName'] = $data_account_access['lastName'];
                    $_SESSION['firstName'] = $data_account_access['firstName'];
                    $_SESSION['emailId'] = $data_account_access['emailId'];
                    $_SESSION['phoneNo'] = $data_account_access['phoneNo'];
    
                    ob_clean();
                    echo "success";
                    exit;
                        
                } else {
                    ob_clean();
                    echo "fail";
                    exit;
                }  
                exit;
            }
            
        }
?>

<!DOCTYPE html>
<html lang="en" class="h-100">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ReavePay | Account Access</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <link href="vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
	<link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	<style>
        /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
        }

        /* Firefox */
        input[type=number] {
        -moz-appearance: textfield;
        }
    </style>
</head>

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="container-fluid">
                    <br>
                    <?php include('alerts.php') ?>
                </div>
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="."><img src="images/logo-full.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Sign in your account</h4>
                                    <form method="POST" onsubmit="return login()">
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Phone No</strong></label>
                                            <input type="number" id="phoneNo" name="textPhoneNo" class="form-control" maxlength="11" placeholder="Phone No">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Password</strong></label>
                                            <input type="password" id="password" name="textPassword" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="form-row d-flex justify-content-between mt-4 mb-2">
                                            <div class="form-group">
                                               <div class="custom-control custom-checkbox ml-1 text-white">
													<input type="checkbox" class="custom-control-input" id="basic_checkbox_1">
													<label class="custom-control-label" for="basic_checkbox_1">Remember my preference</label>
												</div>
                                            </div>
                                            <div class="form-group">
                                                <a class="text-white" href="page-forgot-password.html">Forgot Password?</a>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" id="buttonSignin" class="btn bg-white text-primary btn-block">Sign Me In</button>
                                            <button type="submit" id="loading_spinner" class="btn bg-white text-primary btn-block" style="display: none;"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> Signing In</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p class="text-white">Don't have an account? <a class="text-white" href="signup.php">Sign up</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/deznav-init.js"></script>
    <script src="vendor/sweetalert2/dist/sweetalert2.min.js"></script>
    <script>
        function login() {
            let phoneNo = $("#phoneNo").val();
            let password = $("#password").val();

            if (phoneNo !="" && password != "") {

                $("#buttonSignin").css({"display":"none"});
                $("#loading_spinner").css({"display":"block"});
                $.ajax
                ({
                    type:'post',
                    url:'signin.php',
                    data:{
                        login:"login",
                        phoneNo:phoneNo,
                        password:password
                    },
                    success:function(response) {
                        if(response =="success"){
                            $("#loading_spinner").css({"display":"none"});

                            swal({
                                type: 'success',
                                title: 'Success!',
                                text: "Sign In Successfull",
                                confirmButtonText: 'Continue',
                                type: 'success',
                            }).then(function (result) {
                                if (true) {
                                window.location = "index.php";
                                }
                            })
                        }
                        else {
                            $("#loading_spinner").css({"display":"none"});
                            $("#buttonSignin").css({"display":"block"});

                            swal({
                                type: 'error',
                                title: 'Declined!',
                                text: 'Wrong Phone Number or Password ',
                                confirmButtonText: 'Try Again'
                            });
                            // alert("Wrong Details" + response);
                            // console.log(response + " - " + phoneNo + " - " + password);
                        }
                    }
                });
                
            } else {
                swal({
                    type: "error",
                    title: "Oops!",
                    text: "Please Fill All Details" ,
                    confirmButtonText: "Try Again"
                });
            }
            return false;
            //console.log(response + " - " + phoneNo + " - " + password);
        }
    </script>

</body>


</html>